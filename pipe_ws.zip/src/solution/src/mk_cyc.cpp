#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float64MultiArray.h"
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <nav_msgs/Odometry.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_broadcaster.h>
#include <cmath>
#include <vector>
#include <mutex>
#include <queue>
#include <thread>
#include <chrono>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

double mm_to_m= 1
//0.001
;
// double lastx=0,lasty=0;
double scan_period=1;
std::mutex mutex_lock;
ros::Publisher cyc_pub;
double r=140*mm_to_m;
std::queue<sensor_msgs::PointCloud2ConstPtr> pointCloudBuf;
void handle(const sensor_msgs::PointCloud2ConstPtr &cloud_ros) {
    mutex_lock.lock();
    pointCloudBuf.push(cloud_ros);
    mutex_lock.unlock();
}


void pc_handler() {
    ROS_INFO("mk-cyc running...");
    while (1)
    {
        if (!pointCloudBuf.empty())
        {
            // if(!pointCloudBuf.empty() && pointCloudBuf.front()->header.stamp.toSec()<((roatBuf.front()->data[1])-0.5*scan_period)){
            //     ROS_WARN("handle::time stamp unaligned error and pointcloud discarded, pls check your data --> laser mapping node"); 
            //     pointCloudBuf.pop();
            //     mutex_lock.unlock();
            //     continue;              
            // }
            // if(!roatBuf.empty() && roatBuf.front()->data[1] < pointCloudBuf.front()->header.stamp.toSec()-0.5*scan_period){
            //     roatBuf.pop();
            //     ROS_INFO("handle::time stamp unaligned with path final, pls check your data --> laser mapping node");
            //     mutex_lock.unlock();
            //     continue;  
            // }
            
            mutex_lock.lock();
            
            if (pointCloudBuf.front()->data.size()<6) {
                pointCloudBuf.pop();
                mutex_lock.unlock();
                continue;
            }
            pcl::PointCloud<pcl::PointXYZ>::Ptr raw_cloud(new pcl::PointCloud<pcl::PointXYZ>);
            ros::Time pointcloud_time = (pointCloudBuf.front())->header.stamp;
            pcl::PointCloud<pcl::PointXYZ>::Ptr raw(new pcl::PointCloud<pcl::PointXYZ>);
            // pcl::fromROSMsg(*pointCloudBuf.front(),*raw_cloud);
            pcl::fromROSMsg(*pointCloudBuf.front(),*raw);
            pointCloudBuf.pop();
            mutex_lock.unlock();
            // if (raw_cloud->empty())
            // {
            //     continue;
            // }
            
            // filt(raw_cloud,raw,5);
            
            std::sort(raw->begin(),raw->end(),[](pcl::PointXYZ pt1,pcl::PointXYZ pt2) {
                if (fabs(pt1.x-pt2.x)<2) {
                    return pt1.y<pt2.y;
                }
                return pt1.x<pt2.x;
            });
            
            pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_out(new pcl::PointCloud<pcl::PointXYZ>);
            for (size_t i = 0; i < raw->size()-4; i+=2)
            {
                //ROS_INFO("1:%lf 2:%lf\n",raw->points[i].x,raw->points[i+1].x);
                if (fabs(raw->points[i].x-raw->points[i+1].x)<2*mm_to_m && raw->points[i+1].y-raw->points[i].y>(2*r*2/5)*mm_to_m) {
                    double yl=raw->points[i+1].y-raw->points[i].y;
                    std::pair<double,double> cyc_mid=std::make_pair((raw->points[i].x+raw->points[i+1].x)/2,(raw->points[i].y+raw->points[i+1].y)/2);
                    if (fabs(yl-2*r)>3)
                    {
                        cyc_mid.second-=sqrt(r*r-(yl/2)*(yl/2));
                    }
                    int zd=0;
                    if (yl<2*r) {
                        zd=sqrt(r*r-(yl/2)*(yl/2));
                    }
                    
                    // lastx=std::max(lastx,cyc_mid.first),lasty=std::max(lasty,cyc_mid.second);
                    for (double theta = 0; theta <= 2*M_PI; theta+=18*M_PI/180)
                    {
                        double x,y,z;
                        x=cyc_mid.first;
                        y=r*cos(theta);
                        z=r*sin(theta)-zd;
                        pcl::PointXYZ p(x,y,z);
                        //ROS_INFO("x:%lf y:%lf z:%lf\n",x,y,z);
                        cloud_out->push_back(p);
                    }
                    
                }
                
                
 
            }
            sensor_msgs::PointCloud2 PointsMsg;
            pcl::toROSMsg(*cloud_out, PointsMsg);
            PointsMsg.header.stamp = pointcloud_time;
            PointsMsg.header.frame_id = "base_link";
            cyc_pub.publish(PointsMsg);
            // printf("cyc push\n"); 
            // ROS_INFO("a cyc");

        }
        
        std::chrono::milliseconds dura(2);
        std::this_thread::sleep_for(dura);
    }
    
}
int main(int argc,char** argv) {
    ros::init(argc, argv, "mk_cyc");
    ros::NodeHandle nh;
    ros::Subscriber subLaserCloud = nh.subscribe<sensor_msgs::PointCloud2>("/d3", 100, handle);
    cyc_pub = nh.advertise<sensor_msgs::PointCloud2>("/cyc_pc", 100);
    std::thread handler{pc_handler};
    ros::spin();
}