#include <bits/stdc++.h>
using namespace std;

int ans=0x3f3f3f3f;
int dp[1000][2];
int dfs(vector<int>& nums, int k) {

}
int minCapability(vector<int>& nums, int k) {
    for (int i=0;i<nums.size();i++) {
       
    }
    return ans;
}

int main() {
       
}