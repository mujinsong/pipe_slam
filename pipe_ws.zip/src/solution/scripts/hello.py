#!/usr/bin/env python3
# coding:utf-8
import rospy
import numpy as np
import math
import tf
import tf2_ros
from nav_msgs.msg import Odometry
from geometry_msgs.msg import TransformStamped
from roboticstoolbox import *
pi=np.pi
def rpy2quaternion(roll, pitch, yaw):
    x=math.sin(pitch/2)*math.sin(yaw/2)*math.cos(roll/2)+math.cos(pitch/2)*math.cos(yaw/2)*math.sin(roll/2)
    y=math.sin(pitch/2)*math.cos(yaw/2)*math.cos(roll/2)+math.cos(pitch/2)*math.sin(yaw/2)*math.sin(roll/2)
    z=math.cos(pitch/2)*math.sin(yaw/2)*math.cos(roll/2)-math.sin(pitch/2)*math.cos(yaw/2)*math.sin(roll/2)
    w=math.cos(pitch/2)*math.cos(yaw/2)*math.cos(roll/2)-math.sin(pitch/2)*math.sin(yaw/2)*math.sin(roll/2)
    return x, y, z, w

def rotationMatrixToEulerAngles(R) :

    # assert(isRotationMatrix(R))
    
    sy = math.sqrt(R[0,0] * R[0,0] +  R[1,0] * R[1,0])
    
    singular = sy < 1e-6

    if  not singular :
        x = math.atan2(R[2,1] , R[2,2])
        y = math.atan2(-R[2,0], sy)
        z = math.atan2(R[1,0], R[0,0])
    else :
        x = math.atan2(-R[1,2], R[1,1])
        y = math.atan2(-R[2,0], sy)
        z = 0

    return np.array([x, y, z])

if __name__ == '__main__':
    a_arm = 0.081
    lenof_link = 10
    # 创建节点
    rospy.init_node("pyhello")
    DHs = [RevoluteDH(a=a_arm, alpha=pi / 2, qlim=[-70 * pi / 180, 70 * pi / 180])]
    for i in range(1, lenof_link):
        DHs.append(RevoluteDH(a=a_arm, alpha=(pi / 2) * (-1) ** i, qlim=[-80 * pi / 180, 80 * pi / 180]))
    snake = DHRobot(DHs, name="arm")
    theta_end = [25.5031, -8.5507, -18.6721, 35.7715, -25.3595, 18.9978, 5, 10, -5, 5]
    odom=snake.fkine(theta_end)
    print()
    tf=tf.Transformer()
    odom_frame = '/odom'
    trans = TransformStamped()
    br = tf2_ros.TransformBroadcaster()
    trans.header.stamp = rospy.Time.now()
    trans.header.frame_id = "odom"
    trans.child_frame_id = "base_link"
    trans.transform.translation.x = 0
    trans.transform.translation.y = 0
    trans.transform.translation.z = 0
    for v in odom:
        send_data = Odometry()
        elu=rotationMatrixToEulerAngles(v.R)
        q=rpy2quaternion(elu[0],elu[1],elu[2])
        trans.transform.rotation.x = q[0]
        trans.transform.rotation.x = q[1]
        trans.transform.rotation.x = q[2]
        trans.transform.rotation.x = q[3]
        br.sendTransform(trans)
        send_data.header.frame_id = "odom"
        send_data.header.stamp = rospy.Time.now()
        send_data.child_frame_id = "base_link"
        send_data.pose.pose.position.x = v.t[0]
        send_data.pose.pose.position.y = v.t[1]
        send_data.pose.pose.position.z = v.t[2]
        send_data.pose.pose.orientation.x = q[0]
        send_data.pose.pose.orientation.y = q[1]
        send_data.pose.pose.orientation.z = q[2]
        send_data.pose.pose.orientation.w = q[3]
        print(send_data)
    print("hello Irvingao! this is ur first ros python code! Good luck for u!")
    # rospy.spin()